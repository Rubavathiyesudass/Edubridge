import java.util.Scanner;

public class loopsample4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int factorial=1;
			Scanner scanner = new Scanner(System.in);
			System.out.print("Enter the number:");
			  int num =scanner.nextInt();
				for(int i =1; i<=num; i++)
					factorial = factorial * i;
			{
				System.out.println("factorial number is:" + factorial);
	}
	}
}