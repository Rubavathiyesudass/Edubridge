import java.util.Scanner;

public class SameOrNot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				int num1;
				int num2;
				Scanner scanner = new Scanner(System.in);
			    System.out.println("Enter the number:");
				num1 = scanner.nextInt();
				System.out.println("Enter the Another Number:");
				num2 = scanner.nextInt();
						if (num1 == num2)	 
						{
							System.out.println("Both the Number are same:");
						}
						else if  (num1 != num2)
							    {
								 System.out.println("Both of the Number are   not same:");
							     }
						
	}
}