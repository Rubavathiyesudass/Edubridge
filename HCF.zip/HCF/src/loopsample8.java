import java.util.Scanner;

public class loopsample8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		        int Hcf=0;
				Scanner scanner = new Scanner(System.in);
				System.out.println("Enter the Number1:");
				int num1 = scanner.nextInt();
				System.out.println("Enter the Number2:");
				int num2 = scanner.nextInt();	
				for(int i = 2; i<=num1 | i<=num2; i++)
					{
						if(num1 %i==0 && num2%i==0) 
						{
							Hcf=i;
					}
					}     
						System.out.println("HCF:" +Hcf );
					
						}
			
		}
