package reverse;

import java.util.Scanner;

public class reverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner (System.in);
		System.out.println("Enter the Number:");
		int num = scanner.nextInt();
			int reverse = 0;
				System.out.println("Original Number: "+num);
					while(num!=0)
					{
						int digit = num%10;
						reverse = reverse*10 + digit;
						num/=10;
					}
						System.out.println("Reverse Number:" +reverse);
				
}
	
}
