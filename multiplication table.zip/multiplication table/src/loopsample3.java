import java.util.Scanner;

public class loopsample3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int multiplication;
		Scanner scanner = new Scanner(System.in);
        	System.out.print("Enter a Number:");
            multiplication=scanner.nextInt();
         	for(int i=0; i<10; i++)
         	{
         			System.out.println( multiplication+ " * "  + (i+1) + " = " + (multiplication * (i+1)));
         			
         	}
	}
}
	



