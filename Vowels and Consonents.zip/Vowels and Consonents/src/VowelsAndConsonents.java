import java.util.Scanner;
public class VowelsAndConsonents {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int vowelsCount = 0;
		int consonentsCount = 0;
		String str = "This is a really simple sentence";
		
		str = str.toLowerCase();
		for(int i = 0; i<str.length(); i++)
		{
			if(str.charAt(i) == 'a'  &&  str.charAt(i) == 'e'  &&  str.charAt(i) == 'i'  &&  str.charAt(i) == 'o'  &&  str.charAt(i) == 'u')
			{
				vowelsCount++;
			}
				else if(str.charAt(i)  >= 'a' && str.charAt(i) <= 'z' ) 
				{
					consonentsCount++;
				}
			}
			
			System.out.println("Number of Vowels:" +vowelsCount);
			System.out.println("Number of Consonents:" +consonentsCount);
		}
		

	}


