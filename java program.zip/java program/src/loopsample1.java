
public class loopsample1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	    for(int i=1; i<=10; i++)         // i=5; 5<=10 T
	    	System.out.print(i+" ");    
	    }
	}
