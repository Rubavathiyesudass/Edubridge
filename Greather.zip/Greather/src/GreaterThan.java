import java.util.Scanner;
public class GreaterThan {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num;
		Scanner scanner = new Scanner(System.in);
		do
		{
	    System.out.println("Enter the number:");
		num = scanner.nextInt();
		}
				while(num>100 && num< 200);	     
				System.out.println("Entered number is > 100 and 200");
			
	}

}



