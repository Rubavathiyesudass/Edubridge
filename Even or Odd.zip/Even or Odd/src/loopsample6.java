import java.util.Scanner;

public class loopsample6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the Number count: ");
         int  num = scanner.nextInt();
         int evenNum = 0;
         int oddNum = 0;
	     	for( int start = 1; start <=num; start++)
	     	 {
	     		System.out.println("Enter the number");
	     		int num2 = scanner.nextInt();
	     		if(num2%2==0)
	     		{	
	     			 evenNum+=num2;
	     		 }
	     		 else
	     		 {
	     			 oddNum+= num2;
	  
	     	 }
	    }	 
	     			  System.out.println(" Sum of Even num: " + evenNum);
	     			  System.out.println(" Sum of Odd num: " + oddNum);
	}
	}